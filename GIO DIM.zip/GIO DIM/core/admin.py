from django.contrib import admin
from django.contrib import messages
from django.db import connection
import os
from pathlib import Path
from .models import DimensionParametro, ColumnaDimension, ProyectoDimension

# Quita el enlace "Ver el sitio" del cabezal del admin
admin.site.site_url = None

@admin.register(ProyectoDimension)
class ProyectoDimensionAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'descripcion', 'estado')
    list_filter = ('estado',)
    search_fields = ('proyecto_id','nombre',)
    ordering = ('proyecto_id','nombre',)

    '''def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.filter(estado=True)'''

class ColumnaDimensionInline(admin.TabularInline):
    model = ColumnaDimension
    extra = 1

@admin.register(DimensionParametro)
class DimensionParametroAdmin(admin.ModelAdmin):
    list_display = ('tabla', 'tabla_existe', 'estado')
    list_filter = ('estado',)
    search_fields = ('tabla',)
    ordering = ('tabla',)
    inlines = [ColumnaDimensionInline]
    readonly_fields = ('view_sql_script','anotaciones')
    actions = ['crear_tabla', 'actualizar_tabla', 'eliminar_tabla']

    def _trigger_reload(self):
        """Toca el archivo settings.py para forzar el reinicio del servidor (desarrollo o IIS)"""
        try:
            settings_path = Path(__file__).resolve().parent.parent / 'gio_dim' / 'settings.py'
            if settings_path.exists():
                os.utime(settings_path, None)
        except Exception:
            pass

    def get_actions(self, request):
        actions = super().get_actions(request)
        
        if not request.user.is_superuser:
            actions = None

        return actions
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "proyecto":
            kwargs["queryset"] = ProyectoDimension.objects.filter(estado=True)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

    def tabla_existe(self, obj):
        """Muestra si la tabla existe en la base de datos con un indicador visual"""
        return obj.tabla_creada

    tabla_existe.boolean = True
    tabla_existe.short_description = "Tabla Existe"

    def view_sql_script(self, obj):
        if obj.pk:
            return obj.get_create_table_script()
        return "Guarde primero para ver el script."
    view_sql_script.short_description = "Script SQL (Vista Previa)"

    def anotaciones(self, obj):
       return "Por favor, completar los campos de la tabla y tener en cuenta que la primera columna debe ser la llave primaria."
    anotaciones.short_description = "Anotaciones"

    def crear_tabla(self, request, queryset):
        """Crea las tablas en la base de datos SQL Server"""
        created_count = 0
        error_count = 0
        
        for dimension in queryset:
            try:
                script = dimension.get_create_table_script()
                
                with connection.cursor() as cursor:
                    # Verificar si la tabla ya existe
                    cursor.execute("""
                        SELECT COUNT(*) 
                        FROM INFORMATION_SCHEMA.TABLES 
                        WHERE TABLE_NAME = %s
                    """, [dimension.tabla])
                    
                    exists = cursor.fetchone()[0] > 0
                    
                    if exists:
                        self.message_user(
                            request, 
                            f"La tabla '{dimension.tabla}' ya existe. Use 'Actualizar tabla' para modificarla.",
                            level=messages.WARNING
                        )
                        continue
                    
                    # Crear la tabla
                    cursor.execute(script)
                    created_count += 1
                    
            except Exception as e:
                error_count += 1
                self.message_user(
                    request,
                    f"Error al crear tabla '{dimension.tabla}': {str(e)}",
                    level=messages.ERROR
                )
        
        if created_count > 0:
            self._trigger_reload()
            self.message_user(
                request,
                f"Se crearon {created_count} tabla(s) exitosamente. El servidor se está reiniciando para mostrar los nuevos catálogos.",
                level=messages.SUCCESS
            )
    
    crear_tabla.short_description = "Crear tabla(s) en base de datos"

    def actualizar_tabla(self, request, queryset):
        """Actualiza las tablas existentes agregando o eliminando columnas"""
        updated_count = 0
        error_count = 0
        
        for dimension in queryset:
            try:
                with connection.cursor() as cursor:
                    # Verificar si la tabla existe
                    cursor.execute("""
                        SELECT COUNT(*) 
                        FROM INFORMATION_SCHEMA.TABLES 
                        WHERE TABLE_NAME = %s
                    """, [dimension.tabla])
                    
                    exists = cursor.fetchone()[0] > 0
                    
                    if not exists:
                        self.message_user(
                            request,
                            f"La tabla '{dimension.tabla}' no existe. Use 'Crear tabla' primero.",
                            level=messages.WARNING
                        )
                        continue
                    
                    # Obtener columnas existentes en la base de datos
                    cursor.execute("""
                        SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_NAME = %s
                    """, [dimension.tabla])
                    
                    existing_columns = {row[0].lower(): row for row in cursor.fetchall()}
                    
                    # Obtener columnas del modelo
                    model_columns = {col.nombre.lower(): col for col in dimension.columnas.all()}
                    
                    # Agregar nuevas columnas que no existen en la BD
                    for columna in dimension.columnas.all():
                        col_name_lower = columna.nombre.lower()
                        
                        if col_name_lower not in existing_columns:
                            # Agregar nueva columna
                            alter_script = f"ALTER TABLE {dimension.tabla} ADD [{columna.nombre}] {columna.tipo_dato}"
                            
                            if columna.tipo_dato in ['VARCHAR', 'NVARCHAR', 'CHAR', 'NCHAR'] and columna.longitud:
                                alter_script += f"({columna.longitud})"
                            elif columna.tipo_dato in ['DECIMAL', 'NUMERIC'] and columna.longitud and columna.precision:
                                alter_script += f"({columna.longitud},{columna.precision})"
                            
                            if not columna.es_nulo:
                                alter_script += " NOT NULL"
                            
                            cursor.execute(alter_script)
                    
                    # Eliminar columnas que ya no están en el modelo
                    for col_name_lower in existing_columns.keys():
                        if col_name_lower not in model_columns:
                            # Obtener el nombre original de la columna (con mayúsculas/minúsculas correctas)
                            original_col_name = existing_columns[col_name_lower][0]
                            
                            # Eliminar la columna
                            drop_script = f"ALTER TABLE {dimension.tabla} DROP COLUMN [{original_col_name}]"
                            cursor.execute(drop_script)
                    
                    updated_count += 1
                    
            except Exception as e:
                error_count += 1
                self.message_user(
                    request,
                    f"Error al actualizar tabla '{dimension.tabla}': {str(e)}",
                    level=messages.ERROR
                )
        
        if updated_count > 0:
            self._trigger_reload()
            self.message_user(
                request,
                f"Se actualizaron {updated_count} tabla(s) exitosamente. El servidor se está reiniciando para reflejar los cambios en los modelos.",
                level=messages.SUCCESS
            )
    actualizar_tabla.short_description = "Actualizar tabla(s) existente(s)"
    
    def eliminar_tabla(self, request, queryset):
        """Elimina las tablas de la base de datos SQL Server"""
        deleted_count = 0
        
        for dimension in queryset:
            try:
                # Usamos una transacción para asegurar que el DROP se ejecute
                with connection.cursor() as cursor:
                    # Verifica si la tabla existe (Case Insensitive y con brackets)
                    cursor.execute("""
                        SELECT COUNT(*) 
                        FROM INFORMATION_SCHEMA.TABLES 
                        WHERE TABLE_NAME = %s
                    """, [dimension.tabla])
                    
                    exists = cursor.fetchone()[0] > 0
                    
                    if not exists:
                        self.message_user(
                            request,
                            f"La tabla '{dimension.tabla}' no existe en la base de datos.",
                            level=messages.WARNING
                        )
                        continue
                    
                    # Elimina la tabla usando brackets para evitar problemas con nombres reservados o espacios
                    # NOTA: En MSSQL, DROP TABLE es irreversible
                    drop_script = f"DROP TABLE [{dimension.tabla}]"
                    cursor.execute(drop_script)
                    deleted_count += 1
                    
            except Exception as e:
                self.message_user(
                    request,
                    f"Error crítico al eliminar tabla '{dimension.tabla}': {str(e)}",
                    level=messages.ERROR
                )
        
        if deleted_count > 0:
            # Forzamos la recarga para que el modelo desaparezca de 'Catalogos'
            self._trigger_reload()
            self.message_user(
                request,
                f"Éxito: Se eliminaron {deleted_count} tabla(s) de la base de datos. El servidor se está reiniciando.",
                level=messages.SUCCESS
            )
        else:
            self.message_user(
                request,
                "No se eliminó ninguna tabla.",
                level=messages.INFO
            )

    eliminar_tabla.short_description = "Eliminar tabla(s) físicamente de la BD"


