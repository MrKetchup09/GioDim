from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from import_export import resources, fields
from django.db import models, connection
from core.models import DimensionParametro
import logging

logger = logging.getLogger(__name__)

def register_dynamic_models():
    """
    Registra dinámicamente modelos para las tablas creadas a través de DimensionParametro.
    Esto permite que aparezcan en la sección 'Catalogos' del admin.
    """
    try:
        # Verifica si la tabla de parámetros existe antes de intentar consultar
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'dimension_parametro'")
            if not cursor.fetchone():
                return

        # Se obtienen todas las dimensiones
        dimensions = DimensionParametro.objects.all()
        
        for dim in dimensions:
            if dim.tabla_creada:
                table_name = dim.tabla
                
                # Crea la clase Meta dinámicamente
                class Meta:
                    db_table = table_name
                    managed = False
                    app_label = 'Catalogos'
                    verbose_name = table_name
                    verbose_name_plural = table_name

                # Define los atributos del modelo
                attrs = {
                    '__module__': 'Catalogos.models',
                    'Meta': Meta,
                    '__str__': lambda self: f"{table_name} object ({self.pk})"
                }

                # Agrega campos dinámicamente basados en ColumnaDimension
                columnas = dim.columnas.all()
                list_display = []
                
                for col in columnas:
                    field_name = col.nombre
                    if not col.es_pk:
                        list_display.append(field_name)
                    
                    if col.es_pk:
                        attrs[field_name] = models.AutoField(primary_key=True)
                    else:
                        tipo = col.tipo_dato.upper()
                        nullable = col.es_nulo
                        
                        if 'INT' in tipo:
                            if 'BIG' in tipo:
                                attrs[field_name] = models.BigIntegerField(null=nullable, blank=nullable, verbose_name=field_name)
                            else:
                                attrs[field_name] = models.IntegerField(null=nullable, blank=nullable, verbose_name=field_name)
                        elif 'VARCHAR' in tipo or 'NVARCHAR' in tipo:
                            attrs[field_name] = models.CharField(max_length=col.longitud or 255, null=nullable, blank=nullable, verbose_name=field_name)
                        elif 'DATE' in tipo:
                            if 'TIME' in tipo:
                                attrs[field_name] = models.DateTimeField(null=nullable, blank=nullable, verbose_name=field_name)
                            else:
                                attrs[field_name] = models.DateField(null=nullable, blank=nullable, verbose_name=field_name)
                        elif 'DECIMAL' in tipo or 'NUMERIC' in tipo:
                            attrs[field_name] = models.DecimalField(max_digits=col.longitud or 18, decimal_places=col.precision or 2, null=nullable, blank=nullable, verbose_name=field_name)
                        elif 'BIT' in tipo:
                            attrs[field_name] = models.BooleanField(null=nullable, blank=nullable, verbose_name=field_name)
                        elif 'FLOAT' in tipo:
                            attrs[field_name] = models.FloatField(null=nullable, blank=nullable, verbose_name=field_name)
                        else:
                            attrs[field_name] = models.TextField(null=nullable, blank=nullable, verbose_name=field_name)

                # Crea la clase del modelo
                model_name = "".join(x for x in table_name if x.isalnum())
                model_class = type(model_name, (models.Model,), attrs)

                # Define el recurso para import/export
                class DynamicResource(resources.ModelResource):
                    class Meta:
                        model = model_class
                        # Usar campos explícitos para asegurar que el preview se vea bien
                        fields = [col.nombre for col in columnas if not col.es_pk]
                        import_id_fields = [] 
                        # use_transactions = False evita que SQL Server incremente el IDENTITY en el pre-view (dry-run)
                        use_transactions = False


                # Define la clase Admin dinamica
                admin_attrs = {
                    'resource_class': DynamicResource,
                    'list_display': list_display,
                    'search_fields': list_display,
                    'list_filter': [],
                }
                dynamic_admin_class = type(f"{model_name}Admin", (ImportExportModelAdmin,), admin_attrs)
                
                # Registrar en el sitio de administración
                try:
                    admin.site.register(model_class, dynamic_admin_class)
                except admin.sites.AlreadyRegistered:
                    pass
                    
    except Exception as e:
        logger.debug(f"Registro dinámico omitido: {e}")

# Ejecuta el registro
register_dynamic_models()
