from django.urls import path
from django.views.generic import RedirectView
from django.contrib.auth import views as auth_views
from django.contrib import admin
from . import views

urlpatterns = [
    path('login/', admin.site.login, name='login'),
    path('logout/', views.logout_view, name='logout'),
]