from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from core.models import DimensionParametro

class User(AbstractUser):
    user_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=500, unique=True)
    password = models.CharField(max_length=128)
    
    USERNAME_FIELD = 'username'

    class Meta:
        db_table = 'users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'

class PermisosDimensiones(models.Model):
    PERMISSIONS_CHOICES = [
        (0, 'No permissions'),
        (1, 'Read permissions'),
        (2, 'Full permissions')
    ]
    
    permiso_id = models.AutoField(primary_key=True)
    dimension_id = models.ForeignKey(DimensionParametro, on_delete=models.CASCADE)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    permiso = models.IntegerField(choices=PERMISSIONS_CHOICES, default=0)
    fecha_creacion = models.DateTimeField(default=timezone.now, null=True, blank=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'permisos_dimensiones'
        verbose_name = 'Permiso Dimension'
        verbose_name_plural = 'Permisos Dimensiones'

    
