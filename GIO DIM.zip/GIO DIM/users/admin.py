from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, PermisosDimensiones

@admin.register(User)
class UserAdmin(UserAdmin):
    list_display = ('username', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active')
    search_fields = ('username',)
    ordering = ('username',)

@admin.register(PermisosDimensiones)
class PermisosDimensionesAdmin(admin.ModelAdmin):
    list_display = ('dimension_id', 'user_id', 'permiso')
    list_filter = ('dimension_id', 'user_id', 'permiso')
    search_fields = ('dimension_id__tabla', 'user_id__username', 'permiso')


