from django.db import models
from django.utils import timezone

class ProyectoDimension(models.Model):
    proyecto_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=500)
    descripcion = models.TextField()
    estado = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(default=timezone.now, null=True, blank=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'proyecto_dim'
        verbose_name = 'Proyecto Dimension'
        verbose_name_plural = 'Proyectos Dimensiones'
    
    def __str__(self):
        return self.nombre


class DimensionParametro(models.Model):
    dimension_id = models.AutoField(primary_key=True)
    tabla = models.CharField(max_length=500)
    proyecto = models.ForeignKey(ProyectoDimension, on_delete=models.CASCADE, null=True, blank=True)
    estado = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(default=timezone.now, null=True, blank=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'dimension_parametro'
        verbose_name = 'Dimension Parametro'
        verbose_name_plural = 'Dimension Parametros'
    
    def __str__(self):
        return self.tabla

    @property
    def tabla_creada(self):
        """Verifica dinámicamente si la tabla existe en la base de datos"""
        from django.db import connection
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT COUNT(*) 
                    FROM INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_NAME = %s
                """, [self.tabla])
                return cursor.fetchone()[0] > 0
        except Exception:
            return False

    def get_create_table_script(self):
        script = f"CREATE TABLE {self.tabla} (\n"
        columnas_script = []
        
        for columna in self.columnas.all():
            linea = f"    [{columna.nombre}] {columna.tipo_dato}"
            
            if columna.tipo_dato in ['VARCHAR', 'NVARCHAR', 'CHAR', 'NCHAR'] and columna.longitud:
                linea += f"({columna.longitud})"
            elif columna.tipo_dato in ['DECIMAL', 'NUMERIC'] and columna.longitud and columna.precision:
                linea += f"({columna.longitud},{columna.precision})"
            
            if columna.es_pk:
                linea += " PRIMARY KEY IDENTITY(1,1)"
            elif not columna.es_nulo:
                linea += " NOT NULL"
                
            columnas_script.append(linea)
            
        script += ",\n".join(columnas_script)
        script += "\n);"
        return script


class ColumnaDimension(models.Model):
    TIPOS_DATO = [
        ('INT', 'INT'),
        ('BIGINT', 'BIGINT'),
        ('VARCHAR', 'VARCHAR'),
        ('NVARCHAR', 'NVARCHAR'),
        ('DATE', 'DATE'),
        ('DATETIME', 'DATETIME'),
        ('DECIMAL', 'DECIMAL'),
        ('BIT', 'BIT'),
        ('FLOAT', 'FLOAT'),
    ]

    columna_id = models.AutoField(primary_key=True)
    dimension = models.ForeignKey(DimensionParametro, on_delete=models.CASCADE, related_name='columnas')
    nombre = models.CharField(max_length=100, null=False, help_text="Nombre de la columna")
    orden = models.IntegerField(null=False, default=0, help_text="Orden de la columna")
    tipo_dato = models.CharField(max_length=50, choices=TIPOS_DATO, null=False, help_text="Tipo de dato de la columna")
    longitud = models.IntegerField(null=True, blank=True, help_text="Longitud para campos de texto o total de dígitos para decimales")
    precision = models.IntegerField(null=True, blank=True, help_text="Solo para campos decimales")
    es_pk = models.BooleanField(default=False, verbose_name="Es Llave Primaria")
    es_nulo = models.BooleanField(default=True, verbose_name="Permite Nulos")
    
    class Meta:
        db_table = 'columna_dimension'
        verbose_name = 'Columna Dimension'
        verbose_name_plural = 'Columnas Dimensiones'
        
    def __str__(self):
        return f"{self.dimension.tabla} - {self.nombre}"

    
    
