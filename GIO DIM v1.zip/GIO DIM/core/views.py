from django.shortcuts import render
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from users.models import User, PermisosDimensiones
from core.models import DimensionParametro
from django.db import connection
from django.db import transaction
from django.shortcuts import redirect
from django.http import Http404
from django.contrib import messages

@login_required
def tablas_view(request):
    user = User.objects.get(username=request.user.username)
    
    # Obtener dimensiones con permisos del usuario
    dimensiones_con_permisos = []
    
    # Si es admin, tiene permisos completos en todas las tablas
    if user.is_superuser:
        dimensiones = DimensionParametro.objects.filter(estado=True)
        for dimension in dimensiones:
            dimensiones_con_permisos.append({
                'dimension': dimension,
                'permiso': 2,  # Full permissions
                'permiso_nombre': 'Full permissions',
                'puede_poblar': True
            })
    # Si es staff, puede ver todas las tablas pero solo lectura
    elif user.is_staff:
        dimensiones = DimensionParametro.objects.filter(estado=True)
        for dimension in dimensiones:
            dimensiones_con_permisos.append({
                'dimension': dimension,
                'permiso': 1,  # Read permissions
                'permiso_nombre': 'Read permissions',
                'puede_poblar': False
            })
    # Usuario normal: solo las dimensiones con permisos asignados
    else:
        permisos = PermisosDimensiones.objects.filter(user_id=user).select_related('dimension_id')
        
        for permiso in permisos:
            if permiso.permiso > 0:  # Solo mostrar si tiene algún permiso
                dimensiones_con_permisos.append({
                    'dimension': permiso.dimension_id,
                    'permiso': permiso.permiso,
                    'permiso_nombre': permiso.get_permiso_display(),
                    'puede_poblar': permiso.permiso == 2  # Full permissions
                })
    
    # Serializar datos para JSON
    dimensiones_serialized = []
    for item in dimensiones_con_permisos:
        dimensiones_serialized.append({
            'dimension': {
                'dimension_id': item['dimension'].dimension_id,
                'tabla': item['dimension'].tabla,
            },
            'permiso': item['permiso'],
            'permiso_nombre': item['permiso_nombre'],
            'puede_poblar': item['puede_poblar']
        })
    
    context = {
        'user': {
            'user_id': user.user_id,
            'username': user.username,
            'is_staff': user.is_staff,
            'is_superuser': user.is_superuser,
        },
        'dimensiones_con_permisos': dimensiones_serialized,
    }

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse(context)
    
    return render(request, 'core/index.html', context)
