# Guía de Despliegue en IIS para GIO DIM

## Requisitos Previos

1. **Windows Server** con IIS instalado
2. **Python 3.12** (o la versión que estés usando)
3. **SQL Server** accesible desde el servidor
4. **Permisos de administrador** en el servidor

## Paso 1: Instalar Componentes de IIS

Abre PowerShell como administrador y ejecuta:

```powershell
# Instalar IIS y CGI
Install-WindowsFeature -name Web-Server -IncludeManagementTools
Install-WindowsFeature -name Web-CGI
```

## Paso 2: Instalar wfastcgi

En el servidor, instala wfastcgi:

```bash
pip install wfastcgi
wfastcgi-enable
```

Anota la ruta que te devuelve, la necesitarás para el web.config.

## Paso 3: Preparar el Proyecto

1. **Copia el proyecto** a una ubicación en el servidor, por ejemplo:

   ```
   C:\inetpub\wwwroot\gio_dim
   ```

2. **Instala las dependencias**:

   ```bash
   cd C:\inetpub\wwwroot\gio_dim
   pip install -r requirements.txt
   ```

3. **Configura settings.py para producción**:

   - Cambia `DEBUG = False`
   - Actualiza `ALLOWED_HOSTS = ['tu-dominio.com', 'localhost', '127.0.0.1']`
   - Configura `STATIC_ROOT` correctamente

4. **Recolecta archivos estáticos**:

   ```bash
   python manage.py collectstatic --noinput
   ```

5. **Ejecuta migraciones**:
   ```bash
   python manage.py migrate
   ```

## Paso 4: Configurar IIS

1. **Abre IIS Manager**

2. **Crea un nuevo sitio**:

   - Click derecho en "Sites" → "Add Website"
   - Site name: `GIO_DIM`
   - Physical path: `C:\inetpub\wwwroot\gio_dim`
   - Binding: Puerto 80 (o el que prefieras)

3. **Configura permisos**:

   - Click derecho en el sitio → "Edit Permissions"
   - Pestaña "Security" → "Edit"
   - Agrega el usuario `IIS_IUSRS` con permisos de lectura y ejecución
   - Agrega `IUSR` con los mismos permisos

4. **Configura el Application Pool**:
   - En "Application Pools", encuentra el pool de tu sitio
   - Click derecho → "Advanced Settings"
   - Cambia "Enable 32-Bit Applications" a `False`
   - "Managed Pipeline Mode" debe ser `Integrated`

## Paso 5: Actualizar web.config

El archivo `web.config` ya está creado, pero necesitas actualizar estas rutas según tu instalación:

- `scriptProcessor`: Ruta a tu Python y wfastcgi
- `PYTHONPATH`: Ruta completa a tu proyecto
- `WSGI_LOG`: Ruta donde quieres los logs

## Paso 6: Configurar Archivos Estáticos

En IIS Manager:

1. Selecciona tu sitio
2. Doble click en "Handler Mappings"
3. En el panel derecho, click "View Ordered List"
4. Asegúrate que "StaticFile" esté antes que "Python FastCGI"

## Paso 7: Reiniciar IIS

```powershell
iisreset
```

## Paso 8: Verificar

Abre un navegador y ve a `http://localhost` (o tu dominio configurado)

## Troubleshooting

### Error 500.0

- Verifica que las rutas en web.config sean correctas
- Revisa los logs en `C:\inetpub\logs\wfastcgi.log`
- Asegúrate que Python esté en el PATH del sistema

### Error de permisos

- Verifica que IIS_IUSRS tenga permisos en la carpeta del proyecto
- Verifica permisos en la carpeta de logs

### Archivos estáticos no cargan

- Ejecuta `python manage.py collectstatic` nuevamente
- Verifica la configuración de STATIC_ROOT y STATIC_URL en settings.py
- Asegúrate que la regla de rewrite para static files esté correcta

### Error de base de datos

- Verifica la cadena de conexión en settings.py
- Asegúrate que el servidor tenga acceso a SQL Server
- Verifica que el usuario de IIS tenga permisos en la base de datos

## Configuración de Producción Recomendada

### settings.py adicional:

```python
# Seguridad
SECURE_SSL_REDIRECT = True  # Si usas HTTPS
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True

# CORS (si es necesario)
CORS_ALLOWED_ORIGINS = [
    "https://tu-dominio.com",
]
```

## Alternativa: HttpPlatformHandler

Si prefieres usar HttpPlatformHandler en lugar de FastCGI (más moderno):

1. Descarga e instala HttpPlatformHandler desde Microsoft
2. Usa un servidor WSGI como Waitress o Gunicorn
3. Configura web.config para usar HttpPlatformHandler

Ejemplo de web.config con HttpPlatformHandler:

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <handlers>
      <add name="httpPlatformHandler" path="*" verb="*" modules="httpPlatformHandler" resourceType="Unspecified"/>
    </handlers>
    <httpPlatform processPath="C:\Python312\python.exe"
                  arguments="C:\inetpub\wwwroot\gio_dim\manage.py runserver 127.0.0.1:8000"
                  stdoutLogEnabled="true"
                  stdoutLogFile="C:\inetpub\logs\stdout.log"
                  startupTimeLimit="60">
    </httpPlatform>
  </system.webServer>
</configuration>
```

## Notas Importantes

- **Nunca uses `DEBUG = True` en producción**
- **Cambia el SECRET_KEY** a uno único y seguro
- **Configura HTTPS** para producción
- **Haz backups regulares** de la base de datos
- **Monitorea los logs** regularmente
