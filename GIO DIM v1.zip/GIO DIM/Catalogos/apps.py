from django.apps import AppConfig


class CatalogosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Catalogos"

    def ready(self):
        from .admin import register_dynamic_models
        register_dynamic_models()
