from django.db import models

# NOTA: Los modelos de esta aplicación se registran dinámicamente en admin.py
# basándose en las tablas creadas en el módulo 'core'.
# No es necesario definir clases fijas aquí para las tablas de catálogos dinámicos.
