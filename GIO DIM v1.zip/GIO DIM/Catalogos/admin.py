from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from import_export import resources, fields
from django.db import models, connection
from core.models import DimensionParametro
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import Permission
import logging

logger = logging.getLogger(__name__)

def register_dynamic_models():
    """
    Registra dinámicamente modelos para las tablas creadas a través de DimensionParametro.
    Esto permite que aparezcan en la sección 'Catalogos' del admin.
    """
    try:
        # Verifica si la tabla de parámetros existe antes de intentar consultar
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'dimension_parametro'")
            if not cursor.fetchone():
                return

        # Se obtienen todas las dimensiones
        dimensions = DimensionParametro.objects.all()
        
        for dim in dimensions:
            if dim.tabla_creada:
                table_name = dim.tabla
                
                # Crea la clase Meta dinámicamente
                class Meta:
                    db_table = table_name
                    managed = False
                    app_label = 'Catalogos'
                    verbose_name = table_name
                    verbose_name_plural = table_name

                # Define los atributos del modelo
                attrs = {
                    '__module__': 'Catalogos.models',
                    'Meta': Meta,
                    '__str__': lambda self: f"{table_name} object ({self.pk})"
                }

                # Agrega campos dinámicamente basados en ColumnaDimension
                columnas = dim.columnas.all()
                columnas = columnas.order_by('orden')
                
                # list_display original para el admin attrs
                resolved_list_display = []
                
                # Preparamos los atributos del admin
                admin_attrs = {
                    'search_fields': [col.nombre for col in columnas if not col.es_pk],
                    'list_filter': [],
                    'has_import_permission': lambda self, request: request.user.has_perm(f'Catalogos.add_{model_name.lower()}')
                }

                for col in columnas:
                    field_name = col.nombre
                    
                    if col.es_pk:
                        attrs[field_name] = models.AutoField(primary_key=True)
                        continue # ignora el campo PK
                    
                    # Definición del tipo de dato en el modelo
                    tipo = col.tipo_dato.upper()
                    nullable = col.es_nulo
                    
                    es_numerico = False
                    if 'INT' in tipo:
                        if 'BIG' in tipo:
                            attrs[field_name] = models.BigIntegerField(null=nullable, blank=nullable, verbose_name=field_name)
                        else:
                            attrs[field_name] = models.IntegerField(null=nullable, blank=nullable, verbose_name=field_name)
                    elif 'VARCHAR' in tipo or 'NVARCHAR' in tipo:
                        attrs[field_name] = models.CharField(max_length=col.longitud or 255, null=nullable, blank=nullable, verbose_name=field_name)
                    elif 'DATE' in tipo:
                        if 'TIME' in tipo:
                            attrs[field_name] = models.DateTimeField(null=nullable, blank=nullable, verbose_name=field_name)
                        else:
                            attrs[field_name] = models.DateField(null=nullable, blank=nullable, verbose_name=field_name)
                    elif 'DECIMAL' in tipo or 'NUMERIC' in tipo:
                        es_numerico = True
                        attrs[field_name] = models.DecimalField(max_digits=col.longitud or 18, decimal_places=col.precision or 2, null=nullable, blank=nullable, verbose_name=field_name)
                    elif 'BIT' in tipo:
                        attrs[field_name] = models.BooleanField(null=nullable, blank=nullable, verbose_name=field_name)
                    elif 'FLOAT' in tipo:
                        es_numerico = True
                        attrs[field_name] = models.FloatField(null=nullable, blank=nullable, verbose_name=field_name)
                    else:
                        attrs[field_name] = models.TextField(null=nullable, blank=nullable, verbose_name=field_name)

                    # Si es decimal o float, creamos un método de formato para list_display
                    if es_numerico:
                        method_name = f"format_{field_name}"
                        
                        def make_format_func(fname):
                            def format_func(self, obj):
                                val = getattr(obj, fname)
                                if val is None: return "-"
                                try:
                                    return f"{float(val):,.2f}"
                                except (ValueError, TypeError):
                                    return val
                            format_func.short_description = fname
                            format_func.admin_order_field = fname
                            return format_func
                        
                        admin_attrs[method_name] = make_format_func(field_name)
                        resolved_list_display.append(method_name)
                    else:
                        resolved_list_display.append(field_name)

                # Agrega list_display final
                admin_attrs['list_display'] = resolved_list_display

                # Crea la clase del modelo
                model_name = "".join(x for x in table_name if x.isalnum())
                model_class = type(model_name, (models.Model,), attrs)

                # --- Lógica de Permisos ---
                try:
                    # Asegura que existe el ContentType para este modelo dinámico
                    content_type, created = ContentType.objects.get_or_create(
                        app_label='Catalogos',
                        model=model_name.lower()
                    )

                    # Crea permisos estándar
                    actions = [
                        ('add', f'Can add {table_name}'),
                        ('change', f'Can change {table_name}'),
                        ('delete', f'Can delete {table_name}'),
                        ('view', f'Can view {table_name}'),
                    ]

                    for action_code, action_name in actions:
                        codename = f"{action_code}_{model_name.lower()}"
                        Permission.objects.get_or_create(
                            codename=codename,
                            content_type=content_type,
                            defaults={'name': action_name}
                        )
                except Exception as e:
                    logger.error(f"Error creando permisos para {table_name}: {e}")

                # Define el recurso para import/export
                class DynamicResource(resources.ModelResource):
                    class Meta:
                        model = model_class
                        # Usa campos explícitos para asegurar que el preview se vea bien
                        fields = [col.nombre for col in columnas if not col.es_pk]
                        import_id_fields = [] 

                # Vincula el recurso al admin_attrs que creamos antes
                admin_attrs['resource_class'] = DynamicResource
                
                # Define la clase Admin dinamica
                dynamic_admin_class = type(f"{model_name}Admin", (ImportExportModelAdmin,), admin_attrs)

                
                # Registra en el sitio de administración
                try:
                    admin.site.register(model_class, dynamic_admin_class)
                except admin.sites.AlreadyRegistered:
                    pass
                    
    except Exception as e:
        logger.debug(f"Registro dinámico omitido: {e}")

# El registro se realiza ahora en Catalogos/apps.py para evitar advertencias de inicialización
# register_dynamic_models()
