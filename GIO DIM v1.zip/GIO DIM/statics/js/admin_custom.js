/**
 * Custom JS for GIO DIM Admin
 * Replaces default circle icons with table icons in the sidebar
 */
document.addEventListener('DOMContentLoaded', function() {
    // Función para reemplazar los iconos
    const replaceIcons = () => {
        const circles = document.querySelectorAll('.nav-sidebar .fa-circle');
        circles.forEach(icon => {
            icon.classList.remove('fa-circle');
            icon.classList.remove('far'); // Por si es far fa-circle
            icon.classList.add('fas');    // Forzar solid para fa-table
            icon.classList.add('fa-table');
        });
    };

    replaceIcons();

    const observer = new MutationObserver((mutations) => {
        replaceIcons();
    });

    const sidebar = document.querySelector('.nav-sidebar');
    if (sidebar) {
        observer.observe(sidebar, { childList: true, subtree: true });
    }
});
